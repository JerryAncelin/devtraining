# CloudFormation Git Sync with GitHub — Step-by-Step Guide

## What Git sync is (and isn't)

CloudFormation Git sync is a native AWS feature where CloudFormation watches a
branch in your GitHub repo and **automatically deploys stack changes whenever
you commit to that branch**. No CI/CD pipeline, no GitHub Actions workflow,
no access keys.

**How auth actually works:**

- **GitHub ↔ AWS link**: a GitHub App called *AWS Connector for GitHub*, set up
  through the AWS CodeConnections service (formerly CodeStar Connections).
- **AWS ↔ CloudFormation**: two IAM roles in your AWS account:
  - a **Git sync service role** — lets CloudFormation read your repo via the
    connection
  - a **stack execution role** — has permissions to actually create the
    resources your template defines (EC2, Lambda, etc.)

If you specifically want GitHub Actions with access keys as secrets, that's a
different architecture — let me know and I'll write that one up instead.

---

## Prerequisites

- An AWS account with permission to create IAM roles and CloudFormation stacks
- A GitHub account, and admin rights on the repo you want to connect (you need
  to install a GitHub App on it)
- A CloudFormation template (`.yaml` or `.json`) committed to that repo
- Region note: Git sync isn't available in every region — stick to the major
  ones (us-east-1, us-west-2, eu-west-1, etc.) and you'll be fine

---

## Step 1 — Prepare your GitHub repo

Create a repo (or use an existing one) and commit your CloudFormation template
at a known path. For this guide I'll assume:

```
my-infra-repo/
└── templates/
    └── hello-world-site.yaml
```

Push it to a branch — typically `main`.

> Tip: add a GitHub Action that runs `cfn-lint` on pull requests. Git sync
> won't catch template errors before deploy, so linting in PRs saves you from
> failed stack updates.

---

## Step 2 — Create the CodeConnections connection to GitHub

This is the one-time link between your AWS account and GitHub. You only need
to do this once per account, not per stack.

1. AWS Console → search for **Developer Tools** → **Settings** → **Connections**
   (this is the CodeConnections console).
2. Click **Create connection**.
3. Choose **GitHub** as the provider, give it a name (e.g. `github-main`), and
   click **Connect to GitHub**.
4. A GitHub popup appears asking you to authorize the **AWS Connector for
   GitHub** app. Authorize it.
5. Back in AWS, click **Install a new app**. GitHub opens again — pick which
   repos the connector can access (specific repos is safer than "All repos").
6. Confirm. The connection status flips from **Pending** to **Available**.

Note the connection ARN — you'll see it in the connections list. You don't
need to copy it; the CloudFormation console will let you pick it from a
dropdown later.

---

## Step 3 — Create the Git sync service role

This is the role CloudFormation assumes to read your repo through the
connection.

The easiest path: let the CloudFormation console create it for you in Step 5
(it offers a **New service role** option). If you'd rather create it yourself,
the trust policy is:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "CfnGitSyncTrustPolicy",
      "Effect": "Allow",
      "Principal": {
        "Service": "cloudformation.sync.codeconnections.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

Attach a policy that allows `codeconnections:UseConnection` on your specific
connection ARN, plus `codestar-connections:UseConnection` for backward
compatibility.

---

## Step 4 — Create the stack execution role

This is the role CloudFormation uses to actually create the AWS resources in
your template. Its permissions need to cover everything your template
provisions (Lambda, IAM, API Gateway, etc.).

Trust policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": { "Service": "cloudformation.amazonaws.com" },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

For development you can attach `AdministratorAccess`. **Don't do that in prod**
— scope it to just the resource types your template creates.

---

## Step 5 — Create the stack with Git sync

1. CloudFormation console → **Create stack** → **With new resources (standard)**.
2. Under **Prepare template**, choose **Sync from Git**.
3. **Stack name**: give it one.
4. **Deployment file**: you have two options:
   - **"Generate a deployment file for me"** — CloudFormation will open a PR
     against your repo with a starter deployment file. Easiest for first time.
   - **"I am providing my own file in my repository"** — pick this if you've
     already committed your own (see Step 6 for the format).
5. **Repository details**:
   - Provider: **GitHub**
   - Connection: pick the one from Step 2
   - Repository: pick yours
   - Branch: usually `main`
   - Deployment file path: e.g. `deployments/hello-world.yaml`
6. **Service role**: select your Git sync role from Step 3 (or let it create a
   new one).
7. **Stack execution role**: select the role from Step 4.
8. Review and submit.

If you chose "Generate a deployment file", switch to GitHub now and you'll
find a pull request waiting. Merge it. CloudFormation picks up the merge and
provisions the stack.

The stack might briefly show a failed state before you merge the PR — that's
expected. It clears once the merge lands.

---

## Step 6 — The deployment file format

This is the file Git sync watches alongside your template. It tells
CloudFormation which template to deploy and what parameter values to pass.

```yaml
template-file-path: templates/hello-world-site.yaml
parameters:
  StageName: prod
tags:
  Environment: production
  ManagedBy: git-sync
```

- `template-file-path` is required and is **relative to the repo root**.
- `parameters` map directly to the `Parameters:` block in your template.
- Up to 50 parameters and 50 tags are allowed.

The pattern most teams use: one template, multiple deployment files (one per
environment), each pointing at the same template with different parameter
values. That way `templates/app.yaml` stays the single source of truth, and
`deployments/dev.yaml`, `deployments/staging.yaml`, `deployments/prod.yaml`
each map to their own CloudFormation stack.

---

## Step 7 — Test the sync

1. Edit your CloudFormation template locally. Make a tiny but visible change
   (e.g. add a tag, change a description).
2. Commit and push to the branch Git sync is watching.
3. Open the CloudFormation console → your stack → **Git sync** tab.
4. Within a minute or so you should see a new sync event, then a stack update
   in progress.
5. When it goes green, your change is live.

---

## Step 8 — Optional: pull request previews

Turn on **Enable comment on pull request** in the Git sync settings. From then
on, any PR that touches the template or deployment file gets a comment from
CloudFormation summarizing what would change if the PR were merged — your
"plan before apply" step.

---

## Day-to-day workflow

Once it's wired up:

1. Open a PR with your template change.
2. CI (cfn-lint, etc.) runs on the PR.
3. CloudFormation comments with the change summary on the PR.
4. Reviewer approves, you merge.
5. CloudFormation deploys automatically. You watch progress in the **Git sync**
   tab.

You never run `aws cloudformation deploy` again for that stack.

---

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Connection stuck on **Pending** | GitHub App not installed yet — click "Update pending connection" and install it |
| Sync status **Failed: cannot access repository** | Service role missing `codeconnections:UseConnection`, or connection was made on a different repo |
| Stack stays in **CREATE_FAILED** after first run | You haven't merged the auto-generated deployment file PR yet |
| Sync succeeds but stack doesn't update | Make sure your commit actually changed the template or deployment file. Pushes to other files are ignored |
| `Insufficient permissions` during stack update | Stack execution role is missing perms for a new resource type you added |

---

## Limitations to be aware of

- **No manual approval gate** between merge and deploy. If you need one, use
  the PR comment summary as your review step, or fall back to CodePipeline.
- **Drift isn't auto-corrected.** If someone changes a resource in the
  console, Git sync won't notice until the next commit triggers a sync.
- **One template per stack.** Nested stacks work, but each top-level stack
  needs its own sync config.
- **Secrets don't belong in deployment files.** Reference them via SSM
  Parameter Store or Secrets Manager from inside the template instead.
